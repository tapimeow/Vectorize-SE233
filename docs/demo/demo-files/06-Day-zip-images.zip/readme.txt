Not an image. Vectorize skips this entry, only JPG/PNG are kept.
